Forms processing sample application
===================================

This is a sample application that shows how to process and generate HTML forms. It's quite unstructured, more or less a code dump of samples from the book.