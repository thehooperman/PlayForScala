Twitter Application
===================

This application contains examples of accessing the Twitter REST API, as well as the Twitter streaming API. For the latter one, developer credentials are needed, to be obtained from [Twitter](https://dev.twitter.com).

The streaming API example shows how to use iteratees and websockets.