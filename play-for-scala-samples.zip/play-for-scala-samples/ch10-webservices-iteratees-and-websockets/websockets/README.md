WebSockets sample application
=============================

This is a sample application demonstrating WebSockets
