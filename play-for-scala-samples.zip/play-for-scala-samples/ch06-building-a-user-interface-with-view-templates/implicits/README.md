Implicits sample application
============================

This is a sample application demonstrating passing implicit parameters to templates to avoid repetition.
