import play.api.GlobalSettings

/**
 * TODO: scheduled job to re-calculate product ranking (3.7.2 Scheduled jobs)
 */
object Global extends GlobalSettings {

}
