# 8 Building a single-page JavaScript application with JSON

Sample application from chapter 8 of [Play for Scala](http://bit.ly/playscala).

This sample is a single-page JavaScript application that uses a client written in CoffeeScript to interact with a Play application that provides a RESTful web service.
