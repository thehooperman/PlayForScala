# 1.5 Hello Play!

Sample application from chapter 1 of [Play for Scala](http://bit.ly/playscala).

This sample shows a minimal controller action, a controller action with a request parameter, and a minimal HTML template.
