# 4.6.5 Serving static content

Sample application from chapter 4 of [Play for Scala](http://bit.ly/playscala).

This sample is used in this chapter to demonstrate using Play’s `Asset` controller to serve static content, including reverse routes, ETags and gzip compression. This chapter uses cURL on the command line to demonstrate these features.
