# 4.6 Generating a response

Sample application from chapter 4 of [Play for Scala](http://bit.ly/playscala).

This sample demonstrates how to generate different response content types, and setting HTTP response headers.