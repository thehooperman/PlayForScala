# 4.4 Binding HTTP data to Scala objects

Sample application from chapter 4 of [Play for Scala](http://bit.ly/playscala).

This sample shows an example of the syntax for binding HTTP request data to Scala action method parameters. This application does not generate any output.