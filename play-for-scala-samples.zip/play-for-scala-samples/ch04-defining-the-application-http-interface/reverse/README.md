# 4.5 Generating HTTP calls for actions with reverse routing

Sample application from chapter 4 of [Play for Scala](http://bit.ly/playscala).

This sample shows how to use reverse routing to generate the corresponding URLs for controller actions.
