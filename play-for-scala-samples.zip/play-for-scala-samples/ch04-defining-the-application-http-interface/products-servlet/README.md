# 4.4 Binding HTTP data to Scala objects

Sample application from chapter 4 of [Play for Scala](http://bit.ly/playscala).

This sample shows a Java Servlet with a numeric request parameter, for comparison with the Play equivalent.
