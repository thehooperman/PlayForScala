# 4.2 Controllers - the interface between HTTP and Scala

Sample application from chapter 4 of [Play for Scala](http://bit.ly/playscala).

This sample demonstrates the API for action method declarations and the routes file syntax; it does not generate any output