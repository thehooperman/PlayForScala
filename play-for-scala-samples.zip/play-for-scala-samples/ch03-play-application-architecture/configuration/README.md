# 3.2 Application configuration - enabling features and changing defaults

Sample application from chapter 3 of [Play for Scala](http://bit.ly/playscala).

This sample displays a web page that shows the values of application configuration parameters, demonstrating different features of the configuration file syntax.
