# 3.7 Jobs - starting processes

Sample application from chapter 3 of [Play for Scala](http://bit.ly/playscala).

This sample shows how to manually start an asynchronous job, how to schedule jobs, and how to suspend request processing while waiting for results from an asynchronous job.