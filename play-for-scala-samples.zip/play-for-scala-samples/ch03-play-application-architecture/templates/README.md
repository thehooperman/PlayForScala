# 3.5 View templates - formatting output

Sample application from chapter 3 of [Play for Scala](http://bit.ly/playscala).

This sample demonstrates basic HTML templates.

* `minimal.scala.html` is a the smallest possible valid HTML template, with no dynamic parts
* `title.scala.html` extends the minimal template to add a dynamic title